<footer class="footer">

   <section class="grid">

      <div class="box">
         <img src="images/email-icon.png" alt="">
         <h3>our email</h3>
         <a href="mailto:delicio@gmail.com">delicio@gmail.com</a>
         <a href="mailto:sakshikarna990@gmail.com">sakshikarna990@gmail.com</a>
      </div>

      <div class="box">
         <img src="images/clock-icon.png" alt="">
         <h3>opening hours</h3>
         <p>07:00am to 10:00pm</p>
          <p>20% off on weekdays</p>
      </div>

      <div class="box">
         <img src="images/map-icon.png" alt="">
         <h3>our address</h3>
         <a href="#">Patandhoka, Lalitpur</a>
          <p>Near Bhatbhateni</p>
      </div>

      <div class="box">
         <img src="images/phone-icon.png" alt="">
         <h3>our number</h3>
         <a href="tel:9865395022">9865395022</a>
         <a href="tel:9845988351">9845988351</a>
      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>Delicio</span> | Delicious food at your Doorstep!</div>

</footer>

<div class="loader">
   <img src="images/loader.gif" alt="">
</div>